# 🚀 יוצר תוכן שיווקי בעברית - Next.js

## ⚡ מדריך התקנה מהיר

### דרישות מקדימות:
- Node.js 18+ מותקן
- מפתח API מ-Anthropic

---

## 📦 התקנה (3 שלבים פשוטים!)

### 1️⃣ התקן את החבילות:
```bash
npm install
```

### 2️⃣ צור קובץ `.env`:
```bash
ANTHROPIC_API_KEY=המפתח_שלך_כאן
```

### 3️⃣ הפעל את האפליקציה:
```bash
npm run dev
```

✅ **פתח דפדפן:** http://localhost:3000

---

## 🌐 פרסום באינטרנט (Vercel - חינם!)

### אפשרות 1: דרך האתר (הכי קל!)

1. לך ל: https://vercel.com/
2. הירשם עם GitHub
3. לחץ "Add New Project"
4. העלה את התיקייה / חבר GitHub repo
5. הוסף את `ANTHROPIC_API_KEY` ב-Environment Variables
6. Deploy!

✅ **תקבל URL חי תוך דקה!**

---

### אפשרות 2: דרך Terminal

```bash
# התקן Vercel CLI
npm install -g vercel

# התחבר
vercel login

# פרסם
vercel

# הוסף את המפתח
vercel env add ANTHROPIC_API_KEY
```

✅ **זהו! האתר שלך באוויר!**

---

## 📂 מבנה הפרויקט

```
project/
├── app/
│   ├── api/
│   │   └── generate/
│   │       └── route.js        ← API endpoint
│   ├── globals.css             ← Tailwind styles
│   ├── layout.jsx              ← Layout wrapper
│   └── page.jsx                ← הדף הראשי
├── package.json                ← חבילות
├── tailwind.config.js          ← Tailwind config
├── postcss.config.js           ← PostCSS config
├── next.config.js              ← Next.js config
├── .env                        ← משתני סביבה (אל תשתף!)
└── .gitignore                  ← קבצים להתעלם
```

---

## 🎯 למה Next.js?

✅ **פשוט יותר** - פחות קבצים, פחות בלבול
✅ **מהיר יותר** - אופטימיזציה אוטומטית
✅ **SEO טוב** - Server Side Rendering
✅ **Vercel** - פריסה ב-1 קליק
✅ **API Routes** - Backend מובנה

---

## 💰 עלויות

- **Vercel Hosting:** חינם! (100GB bandwidth)
- **Anthropic API:** $5 חינם בהרשמה
  - כל פוסט: ~₪0.006
  - 3,300 פוסטים עם $5!

**סה"כ להתחלה: ₪0** 🎉

---

## 🐛 פתרון בעיות

### בעיה: "Module not found"
```bash
rm -rf node_modules package-lock.json
npm install
```

### בעיה: "ANTHROPIC_API_KEY is not defined"
- ודא שיש קובץ `.env` בשורש הפרויקט
- ודא שהמפתח נכתב נכון
- הפעל מחדש את השרת (`npm run dev`)

### בעיה: "Port 3000 is already in use"
```bash
# הרוג את התהליך הקודם
kill -9 $(lsof -ti:3000)

# או השתמש בפורט אחר
PORT=3001 npm run dev
```

---

## 🚀 מה הלאה?

עכשיו שהאתר עובד:
1. ✅ תוסיף התחברות משתמשים (NextAuth.js)
2. ✅ תוסיף Database (MongoDB/Supabase)
3. ✅ תוסיף תשלומים (Stripe)
4. ✅ תתחיל למכור!

---

## 📞 צריך עזרה?

- **Next.js Docs:** https://nextjs.org/docs
- **Vercel Docs:** https://vercel.com/docs
- **Anthropic Docs:** https://docs.anthropic.com/

---

**בהצלחה! 🎉**

זכור: כל סטארט-אפ גדול התחיל קטן. המפתח הוא להתחיל! 💪

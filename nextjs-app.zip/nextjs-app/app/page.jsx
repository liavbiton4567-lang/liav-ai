'use client';

import { useState } from 'react';
import { Sparkles, Instagram, Facebook, FileText, Mail, Zap, Copy, Check } from 'lucide-react';

export default function Home() {
  const [businessInfo, setBusinessInfo] = useState('');
  const [contentType, setContentType] = useState('instagram');
  const [tone, setTone] = useState('friendly');
  const [generatedContent, setGeneratedContent] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');

  const contentTypes = [
    { id: 'instagram', name: 'פוסט אינסטגרם', icon: Instagram, color: 'from-purple-500 to-pink-500' },
    { id: 'facebook', name: 'מודעת פייסבוק', icon: Facebook, color: 'from-blue-500 to-blue-600' },
    { id: 'landing', name: 'תוכן לדף נחיתה', icon: FileText, color: 'from-green-500 to-emerald-500' },
    { id: 'email', name: 'ניוזלטר', icon: Mail, color: 'from-orange-500 to-red-500' },
  ];

  const tones = [
    { id: 'friendly', name: 'ידידותי' },
    { id: 'professional', name: 'מקצועי' },
    { id: 'exciting', name: 'נלהב ומרגש' },
    { id: 'humorous', name: 'הומוריסטי' },
  ];

  const generateContent = async () => {
    if (!businessInfo.trim()) {
      setError('אנא הזן מידע על העסק או המוצר שלך');
      return;
    }

    setIsGenerating(true);
    setGeneratedContent('');
    setError('');

    const prompts = {
      instagram: `צור פוסט אינסטגרם מושך בעברית עבור: ${businessInfo}. הטון צריך להיות ${tone === 'friendly' ? 'ידידותי וחם' : tone === 'professional' ? 'מקצועי ואמין' : tone === 'exciting' ? 'נלהב ומרגש' : 'הומוריסטי ומשעשע'}. כלול אמוג'י רלוונטיים והשטאגים. התוכן צריך להיות קצר ומושך תשומת לב.`,
      facebook: `צור מודעת פייסבוק משכנעת בעברית עבור: ${businessInfo}. הטון צריך להיות ${tone === 'friendly' ? 'ידידותי' : tone === 'professional' ? 'מקצועי' : tone === 'exciting' ? 'נלהב' : 'הומוריסטי'}. כלול כותרת חזקה, תיאור מפורט, וקריאה לפעולה ברורה.`,
      landing: `צור תוכן לדף נחיתה בעברית עבור: ${businessInfo}. כלול: כותרת ראשית מושכת, תת-כותרת, 3-4 יתרונות עיקריים, וקריאה לפעולה. הטון: ${tone === 'friendly' ? 'ידידותי' : tone === 'professional' ? 'מקצועי' : tone === 'exciting' ? 'נלהב' : 'הומוריסטי'}.`,
      email: `צור תוכן לניוזלטר מעניין בעברית עבור: ${businessInfo}. כלול נושא אימייל מושך, פתיחה חזקה, גוף מסר ערכי, וקריאה לפעולה. הטון: ${tone === 'friendly' ? 'ידידותי' : tone === 'professional' ? 'מקצועי' : tone === 'exciting' ? 'נלהב' : 'הומוריסטי'}.`,
    };

    try {
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt: prompts[contentType],
        }),
      });

      if (!response.ok) {
        throw new Error('שגיאה ביצירת התוכן');
      }

      const data = await response.json();
      setGeneratedContent(data.content);
    } catch (error) {
      console.error('Error generating content:', error);
      setError('אירעה שגיאה ביצירת התוכן. אנא נסה שוב.');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900 text-white" dir="rtl">
      {/* Decorative background elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>

      <div className="relative max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {/* Header */}
        <div className="text-center mb-12 sm:mb-16 animate-fadeIn">
          <div className="inline-flex items-center gap-3 mb-6 bg-purple-500/10 backdrop-blur-sm px-4 sm:px-6 py-3 rounded-full border border-purple-500/20">
            <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-purple-400 animate-spin" style={{ animationDuration: '3s' }} />
            <span className="text-sm sm:text-base text-purple-300 font-medium">מופעל על ידי AI מתקדם</span>
          </div>
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-black mb-4 bg-gradient-to-l from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent px-4">
            יוצר תוכן שיווקי בעברית
          </h1>
          <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed px-4">
            צור תוכן שיווקי מקצועי ומושך תשומת לב בשניות ספורות באמצעות בינה מלאכותית
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8">
          {/* Input Section */}
          <div className="space-y-6 animate-slideInRight">
            <div className="bg-slate-900/50 backdrop-blur-xl p-6 sm:p-8 rounded-3xl border border-slate-700/50 shadow-2xl">
              <h2 className="text-xl sm:text-2xl font-bold mb-6 flex items-center gap-3">
                <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-yellow-400" />
                פרטי העסק שלך
              </h2>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-slate-300 mb-3">
                    ספר לנו על העסק או המוצר שלך
                  </label>
                  <textarea
                    value={businessInfo}
                    onChange={(e) => setBusinessInfo(e.target.value)}
                    placeholder="לדוגמה: אנחנו מציעים שירותי עיצוב פנים יוקרתיים לדירות ובתים פרטיים. התמחות בסגנון מודרני ומינימליסטי..."
                    className="w-full h-32 bg-slate-800/50 border border-slate-600 rounded-2xl px-4 py-3 text-white placeholder-slate-500 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all outline-none resize-none"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-300 mb-3">
                    סוג התוכן
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {contentTypes.map((type) => {
                      const Icon = type.icon;
                      return (
                        <button
                          key={type.id}
                          onClick={() => setContentType(type.id)}
                          className={`p-3 sm:p-4 rounded-2xl border-2 transition-all duration-300 ${
                            contentType === type.id
                              ? `bg-gradient-to-br ${type.color} border-transparent shadow-lg scale-105`
                              : 'bg-slate-800/30 border-slate-700 hover:border-slate-600 hover:bg-slate-800/50'
                          }`}
                        >
                          <Icon className="w-5 h-5 sm:w-6 sm:h-6 mx-auto mb-2" />
                          <span className="text-xs sm:text-sm font-semibold block">{type.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-300 mb-3">
                    טון הכתיבה
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {tones.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setTone(t.id)}
                        className={`py-2.5 sm:py-3 px-3 sm:px-4 rounded-2xl border-2 transition-all duration-300 font-semibold text-sm ${
                          tone === t.id
                            ? 'bg-purple-600 border-purple-500 shadow-lg scale-105'
                            : 'bg-slate-800/30 border-slate-700 hover:border-slate-600 hover:bg-slate-800/50'
                        }`}
                      >
                        {t.name}
                      </button>
                    ))}
                  </div>
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-4 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                <button
                  onClick={generateContent}
                  disabled={isGenerating}
                  className="w-full bg-gradient-to-l from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-slate-700 disabled:to-slate-700 py-3 sm:py-4 rounded-2xl font-bold text-base sm:text-lg transition-all duration-300 shadow-xl hover:shadow-purple-500/50 hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                  {isGenerating ? (
                    <>
                      <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                      יוצר תוכן מדהים...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      צור תוכן
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Output Section */}
          <div className="animate-slideInLeft">
            <div className="bg-slate-900/50 backdrop-blur-xl p-6 sm:p-8 rounded-3xl border border-slate-700/50 shadow-2xl h-full">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-3">
                  <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-purple-400" />
                  התוכן שלך
                </h2>
                {generatedContent && (
                  <button
                    onClick={copyToClipboard}
                    className="flex items-center gap-2 bg-slate-800 hover:bg-slate-700 px-3 sm:px-4 py-2 rounded-xl transition-all"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-green-400" />
                        <span className="text-xs sm:text-sm text-green-400">הועתק!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4" />
                        <span className="text-xs sm:text-sm">העתק</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              <div className="bg-slate-800/50 border border-slate-700 rounded-2xl p-4 sm:p-6 min-h-[300px] sm:min-h-[400px]">
                {generatedContent ? (
                  <div className="text-slate-200 text-sm sm:text-base leading-relaxed whitespace-pre-wrap">
                    {generatedContent}
                  </div>
                ) : (
                  <div className="h-full flex items-center justify-center text-slate-500">
                    <div className="text-center">
                      <Sparkles className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 opacity-30" />
                      <p className="text-base sm:text-lg">התוכן שלך יופיע כאן</p>
                      <p className="text-xs sm:text-sm mt-2">מלא את הפרטים והקלק על "צור תוכן"</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Features */}
        <div className="mt-12 sm:mt-16 grid sm:grid-cols-3 gap-4 sm:gap-6 animate-fadeIn" style={{ animationDelay: '0.3s' }}>
          {[
            { title: 'מהיר וקל', desc: 'תוכן איכותי תוך שניות' },
            { title: 'מותאם אישית', desc: 'טון וסגנון לפי הצורך שלך' },
            { title: 'מקצועי', desc: 'תוכן ברמה שיווקית גבוהה' },
          ].map((feature, i) => (
            <div
              key={i}
              className="bg-slate-900/30 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-4 sm:p-6 text-center hover:bg-slate-900/50 transition-all duration-300 hover:scale-105"
            >
              <h3 className="text-lg sm:text-xl font-bold mb-2 text-purple-400">{feature.title}</h3>
              <p className="text-sm sm:text-base text-slate-400">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(-30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes slideInLeft {
          from { opacity: 0; transform: translateX(30px); }
          to { opacity: 1; transform: translateX(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.8s ease-out;
        }
        .animate-slideInRight {
          animation: slideInRight 0.8s ease-out;
        }
        .animate-slideInLeft {
          animation: slideInLeft 0.8s ease-out;
        }
      `}</style>
    </div>
  );
}

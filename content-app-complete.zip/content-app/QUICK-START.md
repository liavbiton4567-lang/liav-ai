# ⚡ מדריך התחלה מהירה - 5 דקות!

## אם אין לך סבלנות למדריך המלא 😅

### 📦 מה צריך:
- [x] Node.js מותקן
- [x] מפתח API מ-Anthropic

---

## 🚀 3 שלבים פשוטים:

### 1️⃣ Backend (שרת)

```bash
# צור תיקייה
mkdir content-app
cd content-app

# צור backend
mkdir backend
cd backend

# התקן
npm init -y
npm install express cors dotenv @anthropic-ai/sdk

# צור server.js (העתק מהקוד שקיבלת)

# צור .env
echo "ANTHROPIC_API_KEY=המפתח_שלך" > .env
echo "PORT=3001" >> .env

# הפעל!
node server.js
```

✅ **אם רואה "Server is running" - מעולה!**

---

### 2️⃣ Frontend (אתר)

**פתח Terminal חדש:**

```bash
# חזור לתיקיה הראשית
cd ..

# צור React app
npx create-react-app frontend
cd frontend

# התקן חבילות
npm install lucide-react
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# הגדר Tailwind (ראה מדריך מלא)

# העתק App.jsx ל-src/App.js

# הוסף לpackage.json:
"proxy": "http://localhost:3001"

# הפעל!
npm start
```

✅ **אמור להיפתח בדפדפן!**

---

### 3️⃣ פרסום באינטרנט (אופציונלי)

```bash
# התקן Vercel
npm install -g vercel

# Backend
cd backend
vercel
# הוסף את ANTHROPIC_API_KEY בהגדרות

# Frontend
cd ../frontend
npm run build
vercel
```

✅ **קיבלת URL? יש לך אתר באינטרנט!**

---

## 🎯 זהו! פשוט כך!

יש בעיות? ראה את המדריך המלא: `INSTALLATION-GUIDE.md`

**בהצלחה! 🚀**

# 🚀 מדריך התקנה מלא - יוצר תוכן שיווקי בעברית

## 📋 תוכן עניינים
1. [דרישות מקדימות](#דרישות-מקדימות)
2. [התקנה מקומית](#התקנה-מקומית)
3. [פריסה לאינטרנט (חינם!)](#פריסה-לאינטרנט)
4. [קבלת API Key](#קבלת-api-key)
5. [פתרון בעיות](#פתרון-בעיות)

---

## 📌 דרישות מקדימות

לפני שמתחילים, ודא שיש לך:

### 1. Node.js (חובה!)
- **הורד מ:** https://nodejs.org/
- **גרסה מומלצת:** 18.0 ומעלה
- **בדיקה:** פתח Terminal/CMD והקלד:
  ```bash
  node --version
  npm --version
  ```
  אם רואה מספרי גרסה - מעולה! אם לא - התקן Node.js

### 2. עורך קוד (מומלץ)
- **Visual Studio Code** - https://code.visualstudio.com/
- חינם ונוח מאוד!

### 3. חשבון Anthropic (לAPI)
- **הרשם ב:** https://console.anthropic.com/
- תקבל $5 קרדיט חינם!

---

## 💻 התקנה מקומית (על המחשב שלך)

### שלב 1: יצירת התיקיות

1. **צור תיקייה חדשה למشל בשולחן העבודה:**
   ```bash
   mkdir hebrew-content-app
   cd hebrew-content-app
   ```

### שלב 2: הגדרת Backend (שרת)

1. **צור תיקיית Backend:**
   ```bash
   mkdir backend
   cd backend
   ```

2. **אתחל פרויקט Node.js:**
   ```bash
   npm init -y
   ```

3. **התקן את החבילות הנדרשות:**
   ```bash
   npm install express cors dotenv @anthropic-ai/sdk
   npm install --save-dev nodemon
   ```

4. **העתק את הקבצים:**
   - העתק את `server.js` לתיקייה
   - העתק את `package.json` לתיקייה

5. **צור קובץ `.env`:**
   ```bash
   ANTHROPIC_API_KEY=הדבק_כאן_את_המפתח_שלך
   PORT=3001
   ```
   
   **חשוב:** לא לשתף את הקובץ הזה עם אף אחד!

6. **הפעל את השרת:**
   ```bash
   npm run dev
   ```
   
   אם רואה "🚀 Server is running on port 3001" - הכל עובד! 🎉

### שלב 3: הגדרת Frontend (ממשק המשתמש)

**פתח חלון Terminal חדש** (השאר את השרת רץ!)

1. **חזור לתיקייה הראשית:**
   ```bash
   cd ..
   ```

2. **צור אפליקציית React:**
   ```bash
   npx create-react-app frontend
   cd frontend
   ```

3. **התקן Tailwind CSS:**
   ```bash
   npm install -D tailwindcss postcss autoprefixer
   npx tailwindcss init -p
   ```

4. **התקן Lucide Icons:**
   ```bash
   npm install lucide-react
   ```

5. **ערוך `tailwind.config.js`:**
   ```javascript
   /** @type {import('tailwindcss').Config} */
   module.exports = {
     content: [
       "./src/**/*.{js,jsx,ts,tsx}",
     ],
     theme: {
       extend: {},
     },
     plugins: [],
   }
   ```

6. **ערוך `src/index.css`:**
   ```css
   @tailwind base;
   @tailwind components;
   @tailwind utilities;
   ```

7. **החלף את `src/App.js`:**
   - העתק את התוכן מ-`App.jsx` לקובץ `src/App.js`

8. **הוסף proxy ל-`package.json`:**
   הוסף את השורה הזאת בכל מקום בקובץ:
   ```json
   "proxy": "http://localhost:3001",
   ```

9. **הפעל את האפליקציה:**
   ```bash
   npm start
   ```

🎉 **זהו! האתר שלך אמור להיפתח בדפדפן!**

---

## 🌐 פריסה לאינטרנט (חינם!)

### אפשרות 1: Vercel (מומלץ!)

#### Backend על Vercel:

1. **הרשם ל-Vercel:**
   - לך ל: https://vercel.com/
   - הירשם עם GitHub

2. **התקן Vercel CLI:**
   ```bash
   npm install -g vercel
   ```

3. **בתיקיית Backend, צור `vercel.json`:**
   ```json
   {
     "version": 2,
     "builds": [
       {
         "src": "server.js",
         "use": "@vercel/node"
       }
     ],
     "routes": [
       {
         "src": "/(.*)",
         "dest": "server.js"
       }
     ],
     "env": {
       "ANTHROPIC_API_KEY": "@anthropic_api_key"
     }
   }
   ```

4. **פרסם את Backend:**
   ```bash
   cd backend
   vercel
   ```
   
   עקוב אחרי ההוראות על המסך.

5. **הוסף את המפתח בצורה מאובטחת:**
   ```bash
   vercel env add ANTHROPIC_API_KEY
   ```
   הדבק את המפתח שלך.

6. **תקבל URL כמו:**
   ```
   https://your-app-name.vercel.app
   ```

#### Frontend על Vercel:

1. **עדכן את `App.js` - שנה את הקריאה ל-API:**
   ```javascript
   const response = await fetch('https://your-backend-url.vercel.app/api/generate', {
   ```

2. **בנה את האפליקציה:**
   ```bash
   cd frontend
   npm run build
   ```

3. **פרסם:**
   ```bash
   vercel
   ```

🌟 **זהו! עכשיו יש לך אתר חי באינטרנט!**

---

### אפשרות 2: Netlify (אלטרנטיבה)

1. **הרשם ל-Netlify:** https://www.netlify.com/
2. **גרור את תיקיית `build` לאתר**
3. **הוסף משתני סביבה בהגדרות**

---

### אפשרות 3: Railway (Backend + Frontend)

1. **הרשם ל-Railway:** https://railway.app/
2. **חבר את GitHub repo**
3. **הוסף משתני סביבה**
4. **Deploy!**

---

## 🔑 קבלת API Key מ-Anthropic

### שלב 1: הרשמה
1. לך ל: https://console.anthropic.com/
2. הירשם עם Google/Email
3. אמת את האימייל

### שלב 2: קבלת המפתח
1. בקונסול, לחץ על **"API Keys"**
2. לחץ על **"Create Key"**
3. תן שם למפתח (למשל: "Content Generator")
4. העתק את המפתח - **לא תראה אותו שוב!**

### שלב 3: שימוש במפתח
- **פיתוח מקומי:** שים ב-`.env`
- **פרודקשן:** שים ב-Vercel/Netlify Secrets

### 💰 תמחור
- **$5 חינם** בהרשמה
- **~$0.003** ל-1000 tokens (מילים)
- **פוסט ממוצע:** ~500 tokens = $0.0015
- **100 פוסטים:** ~$0.15

**לדוגמה:** עם $5 תוכל ליצור **~3,300 פוסטים**!

---

## 🐛 פתרון בעיות נפוצות

### בעיה: "Cannot find module 'express'"
**פתרון:**
```bash
cd backend
npm install
```

### בעיה: "ANTHROPIC_API_KEY is not defined"
**פתרון:**
- ודא שיש קובץ `.env` בתיקיית backend
- ודא שהמפתח נכתב נכון (ללא רווחים!)
- הפעל מחדש את השרת

### בעיה: "Port 3001 is already in use"
**פתרון:**
שנה ב-`.env`:
```
PORT=3002
```

### בעיה: CORS Error
**פתרון:**
ודא ש-`cors` מותקן ומופעל ב-`server.js`:
```javascript
const cors = require('cors');
app.use(cors());
```

### בעיה: האתר לא נטען
**פתרון:**
1. ודא ש-Backend רץ (port 3001)
2. ודא ש-Frontend רץ (port 3000)
3. רענן את הדפדפן (Ctrl+F5)
4. בדוק Console בדפדפן (F12)

---

## 📞 צריך עזרה?

### משאבים מועילים:
- **Anthropic Docs:** https://docs.anthropic.com/
- **React Docs:** https://react.dev/
- **Vercel Docs:** https://vercel.com/docs
- **Node.js Docs:** https://nodejs.org/docs/

### טיפים:
1. **שמור גיבויים** של הקוד (GitHub!)
2. **התחל קטן** - לא צריך הכל מהיום הראשון
3. **תבדוק לוגים** - הם יעזרו לך למצוא בעיות
4. **קהילה** - יש המון קבוצות עזרה בפייסבוק/דיסקורד

---

## 🎯 מה הלאה?

עכשיו שהאתר עובד, אתה יכול:

1. ✅ **להוסיף התחברות משתמשים** (Firebase/Auth0)
2. ✅ **לשמור היסטוריה** של תכנים (MongoDB/PostgreSQL)
3. ✅ **להוסיף תשלומים** (Stripe)
4. ✅ **לבנות דף נחיתה שיווקי**
5. ✅ **להתחיל למכור!**

---

## 🚀 בהצלחה!

יש לך סטארט-אפ! עכשיו קדימה:
1. תבדוק שהכל עובד
2. תראה לחברים
3. תקבל פידבק
4. תשפר
5. תתחיל למכור!

**זכור:** כל סטארט-אפ גדול התחיל קטן. המפתח הוא להתחיל! 💪

---

**יצר: Claude 4.5 Sonnet 🤖**
**רישיון: MIT - חופשי לשימוש!**
